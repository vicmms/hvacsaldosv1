<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface LoginViewResponse extends Responsable
{
    //
}
